-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: dabidDB
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chat`
--

DROP TABLE IF EXISTS `chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat` (
  `chat_id` int NOT NULL AUTO_INCREMENT,
  `chat_content` varchar(200) DEFAULT NULL,
  `chat_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `chat_from` varchar(255) DEFAULT NULL,
  `prd_id` int DEFAULT NULL,
  PRIMARY KEY (`chat_id`),
  KEY `FKg5hvixingf5o9xq6920ktngn9` (`prd_id`),
  CONSTRAINT `FKg5hvixingf5o9xq6920ktngn9` FOREIGN KEY (`prd_id`) REFERENCES `result` (`prd_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat`
--

LOCK TABLES `chat` WRITE;
/*!40000 ALTER TABLE `chat` DISABLE KEYS */;
INSERT INTO `chat` VALUES (1,'안녕하세요 ','2021-08-19 17:44:38','쓰윤서',5),(2,'안녕하세용','2021-08-19 18:47:43','클라쓰',27),(3,'안녕하세요!','2021-08-19 18:47:51','쓰윤서',27),(4,'계좌번호 알려주세요!','2021-08-19 18:48:00','클라쓰',27),(5,'ssafy은행 123-xxx-xxxx입니당!','2021-08-19 18:48:06','쓰윤서',27),(6,'네 감사합니다','2021-08-19 18:48:11','클라쓰',27),(7,'감사합니당 ~~~','2021-08-19 18:48:16','쓰윤서',27),(8,'입금하고 알려드릴게요!','2021-08-19 18:48:16','클라쓰',27),(9,'넵!','2021-08-19 18:48:19','쓰윤서',27);
/*!40000 ALTER TABLE `chat` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20 10:26:34
