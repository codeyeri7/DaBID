-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: dabidDB
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `live`
--

DROP TABLE IF EXISTS `live`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `live` (
  `prd_id` int NOT NULL AUTO_INCREMENT,
  `live_date` datetime(6) DEFAULT NULL,
  `live_desc` varchar(100) DEFAULT NULL,
  `live_title` varchar(50) DEFAULT NULL,
  `prd_name` varchar(50) DEFAULT NULL,
  `prd_no` varchar(100) DEFAULT NULL,
  `prd_photo` varchar(200) DEFAULT NULL,
  `prd_price_start` int NOT NULL,
  `live_status` int DEFAULT NULL,
  `prd_category` int DEFAULT NULL,
  `prd_seller_id` varchar(14) DEFAULT NULL,
  PRIMARY KEY (`prd_id`),
  KEY `FKrri5mrosauga9hg5yjcbqa392` (`live_status`),
  KEY `FK7l5wmjdtd5v915quh6tpgd8rv` (`prd_category`),
  KEY `FKlheg49lucpq4xf2n5d4wyp86a` (`prd_seller_id`),
  CONSTRAINT `FK7l5wmjdtd5v915quh6tpgd8rv` FOREIGN KEY (`prd_category`) REFERENCES `product_category` (`prd_category`),
  CONSTRAINT `FKlheg49lucpq4xf2n5d4wyp86a` FOREIGN KEY (`prd_seller_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKrri5mrosauga9hg5yjcbqa392` FOREIGN KEY (`live_status`) REFERENCES `live_status` (`live_status`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `live`
--

LOCK TABLES `live` WRITE;
/*!40000 ALTER TABLE `live` DISABLE KEYS */;
INSERT INTO `live` VALUES (1,'2021-08-24 22:00:00.000000','선물받고 집에 모셔놓은 지갑입니다. 싸게 드릴께요.','선물받고 한번도 사용안한 지갑입니다!','21SS마르지엘라 스티치 로고 반지갑','5404586949','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/%E1%84%86%E1%85%A1%E1%84%85%E1%85%B3%E1%84%8C%E1%85%B5%E1%84%8B%E1%85%A6%E1%86%AF%E1%84%85%E1%85%A1%E1%84%8C%E1%85%B5%E1%84%80%E1%85%A1%E1%86%B899.jpeg',250000,1,3,'P1629388322486'),(2,'2021-08-23 18:00:00.000000','37사이즈 정품','그냥 새거 로에베 아나그램 스니커즈','로에베 아나그램 스니커즈','LS48456145','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/%EB%A1%9C%EC%97%90%EB%B2%A0%EC%95%84%EB%82%98%EA%B7%B8%EB%9E%A8%EC%8A%A4%EB%8B%88%EC%BB%A4%EC%A6%881804.jpg',450000,2,2,'P1629388262033'),(3,'2021-08-26 12:00:00.000000','여름에만 몇번 사용한 팔찌입니다. 사용감 별로 안느껴져요~','활용도 완전 높은 티파니 팔찌!','티파니 블루 하트 태그 브레이슬릿','20200523','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/%E1%84%90%E1%85%B5%E1%84%91%E1%85%A1%E1%84%82%E1%85%B5%E1%84%91%E1%85%A1%E1%86%AF%E1%84%8D%E1%85%B599.png',200000,1,3,'P1629388322486'),(4,'2021-08-27 08:00:00.000000','산 지 한 달 됐는데 제 스타일과 맞지 않아 부득이하게 판매합니다ㅠㅠ 상태 완전 좋아요!!','버버리 타이틀백 한 달 됨','버버리 타이틀백','BUR-9762','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/0951%20%EB%B2%84%EB%B2%84%EB%A6%AC%20%EA%B0%80%EB%B0%A9.png',1100000,0,1,'P1629388281110'),(5,'2021-08-20 01:30:00.000000','프라다#명품#정품#상태좋음#숄더끈 탈부착 가능프라다#명품#정품#상태좋음#숄더끈 탈부착 가능','프라다 정품 가방입니다.','21시즌 프라다 숄더백','326-212-dsdf-32','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/0819Bag.PNG',350000,2,1,'P1629388892900'),(6,'2021-08-23 20:30:00.000000','정품입니다~','꼼데 땡땡이 지갑','꼼데가르송 지갑','SA3100PD','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/%EA%BC%BC%EB%8D%B0%EC%A7%80%EA%B0%911804.jpg',70000,0,3,'P1629388262033'),(7,'2021-08-21 03:00:00.000000','아미 로고 가디건입니다~ 시작가 낮아요!!','가을 준비가능한 가디건 보고 가세요','아미 로고 가디건','794613852','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/%E1%84%8B%E1%85%A1%E1%84%86%E1%85%B5%E1%84%80%E1%85%A1%E1%84%83%E1%85%B5%E1%84%80%E1%85%A5%E1%86%AB99.png',250000,0,0,'P1629388322486'),(8,'2021-08-24 07:00:00.000000','천연 소가죽이라 부드럽고 매우 편합니다. 사이즈 미스로 판매합니다. 많이들 들어오셔서 참여해주세요!','구찌 남성 로퍼 판매합니다','구찌 남성 로퍼','GU-1982','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/0951%20%EA%B5%AC%EC%B0%8C%20%EA%B5%AC%EB%91%90.png',680000,0,2,'P1629388281110'),(9,'2021-08-20 16:30:00.000000','싸게 팔아요 흠집없는 S급','보테가베네타 반지갑','보테가베네타 반지갑','529121V46511000','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/0818_%EB%B3%B4%ED%85%8C%EA%B0%80%EB%B2%A0%EB%84%A4%ED%83%80_0204.png',150000,0,3,'P1629389126776'),(10,'2021-08-21 21:00:00.000000','딱 3번 착용한 모자 입니다. 따뜻하고 귀여워용','주말이 돌아오는 기념 비니 사세요!!','아크네 패티 울 비니','4084653','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/%E1%84%8B%E1%85%A1%E1%84%8F%E1%85%B3%E1%84%82%E1%85%A6%E1%84%87%E1%85%B5%E1%84%82%E1%85%B599.jpg',150000,0,3,'P1629388322486'),(11,'2021-08-26 03:21:00.000000','멀버리 뱅글, 멀버리 팔찌, 실버뱅글, 실버팔찌, 명품뱅글, 명품팔찌','들어와서 구경하세요!','멀버리 실버 뱅글 링','12-sv93f-12','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/0831ring.PNG',250000,0,3,'P1629388892900'),(12,'2021-08-27 23:30:00.000000','롯데백화점 110만원 구매','☆ 정품 ☆ 구찌시계','구찌시계','GC54871787','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/%EA%B5%AC%EC%B0%8C%EC%8B%9C%EA%B3%84.jfif',540000,0,3,'P1629388262033'),(13,'2021-08-21 19:40:00.000000','상태좋은 S급 팝니다. 직접 백화점 가서 샀고 보증서 있어요','보테가베네타 장지갑 팔아요','보테가베네타 장지갑','63245VCPP32333','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/0819_%EB%B3%B4%ED%85%8C%EA%B0%80%EB%B2%A0%EB%84%A4%ED%83%80_0204.png',200000,0,3,'P1629389126776'),(14,'2021-08-24 10:00:00.000000','최근에 샀는데 생각보다 커서 판매합니다. 상태는 당연 최상입니다.','루이비통 가방 팝니다. 21 S/S','루이비통 쇼퍼백','LU-714','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/0951%20%EB%A3%A8%EC%9D%B4%EB%B9%84%ED%86%B5%20%EA%B0%80%EB%B0%A9.png',2400000,0,1,'P1629388281110'),(15,'2021-08-24 06:00:00.000000','사이즈 225~230 맞아요! 와서 구경하세요','펜디풀박스 구매상태 그대로','펜디 핀턱 디테일 아이보리 신발','3535-22dsf3','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/0823Fendi.PNG',350000,0,2,'P1629388892900'),(16,'2021-08-25 17:15:00.000000','시착만 해본 새상품입니다!','[새상품] 에르메스 스카프 판매합니다','에르메스 트윌리 스카프','H063587S','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/%ED%8A%B8%EC%9C%8C%EB%A6%AC%EC%8A%A4%EC%B9%B4%ED%94%841804.jpg',200000,0,0,'P1629388262033'),(17,'2021-08-22 18:30:00.000000','거의 새거입니다. 한번도안썼는데 색깔 마음에 안들어서 팔아요','보테가베네타 미니백','보테가베네타 미니백','630545VCPP39033','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/0820_%EB%B3%B4%ED%85%8C%EA%B0%80%EB%B2%A0%EB%84%A4%ED%83%80_0204.png',2500000,0,1,'P1629389126776'),(18,'2021-08-24 09:00:00.000000','작년에 샀는데 거의 안 들고나가 완전 새제품입니다. 너무 예쁜데 급하게 돈이 필요해 팝니다ㅠㅠㅠ','펜디 클러치백 사용감 제로','펜디 클러치백','FE-951','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/0951%20%ED%8E%9C%EB%94%94%20%ED%81%B4%EB%9F%AC%EC%B9%98%EB%B0%B1.png',570000,0,1,'P1629388281110'),(19,'2021-08-21 07:30:00.000000','선물받앗는데 정말 단한번도 착용하지않아 어울리실분에게 새주인찾아드려요~','하자 전혀 없어요! 구경오세요','구찌 오피디아 탬버린백 원형백','123-sdf-32','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/0825gucci.PNG',1200000,2,1,'P1629388892900'),(20,'2021-08-24 06:40:00.000000','한번 신고 거의안썼습니다. 상태 아주 좋고 S급이고 보증서 바로 드려요','보테가베네타 부츠','보테가베네타 부츠','6875545VCPP39034','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/0821_%EB%B3%B4%EB%84%A4%EA%B0%80%EB%B2%A0%EB%84%A4%ED%83%80_0204.png',450000,0,2,'P1629389126776'),(21,'2021-08-21 22:30:00.000000','','LOUIS QUATORZE 정품 가방','루이까또즈 가방','LQ198781123','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/%EB%A3%A8%EC%9D%B4%EA%B9%8C%EB%98%90%EC%A6%881804.PNG',65000,0,1,'P1629388262033'),(22,'2021-08-22 08:00:00.000000','작년에 샀는데 새로 선물받아 판매합니다. 상태 좋아요. 라이브로 확인해보세요!','샤넬 지갑 깨끗해요','샤넬 지갑','CH-861','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/0951%20%EC%83%A4%EB%84%AC%20%EC%A7%80%EA%B0%91.png',300000,0,3,'P1629388281110'),(23,'2021-08-25 15:20:00.000000','보테가베네타 가방팝니다. 흠집이 좀 있고 2년 정도써서싸게 팝니다','보테가베네타 가방','보테가베네타 가방','630545VCPP39037','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/0822_%EB%B3%B4%ED%85%8C%EA%B0%80%EB%B2%A0%EB%84%A4%ED%83%80_0204.png',1000000,0,1,'P1629389126776'),(24,'2021-08-23 03:00:00.000000','완전 고급스러워보여요!','결혼식 때 한 번 들었던 가방입니다','루이비통 마이락미 샤첼','234321854','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/%E1%84%85%E1%85%AE%E1%84%8B%E1%85%B5%E1%84%87%E1%85%B5%E1%84%84%E1%85%A9%E1%86%BC99.png',2000000,0,1,'P1629388322486'),(25,'2021-08-26 20:00:00.000000','산 지 한 달도 안됐는데 급전이 필요해서 판매합니다 최상급입니다!','입생로랑 지갑 판매합니다','입생로랑 지갑','up29817','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/082020wallet.png',250000,0,3,'P1629389126776'),(26,'2021-08-26 20:00:00.000000','산 지 한 달도 안됐는데 새로운 지갑 선물받아서 팝니다 상태 완전 좋아요','입생로랑 지갑 최상급팝니다','입생로랑 지갑','ip2818','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/082020wallet.png',350000,0,3,'P1629389126776'),(27,'2021-08-20 06:25:00.000000','','한정판 YSL 가방 보러오세요~','20시즌 입생로랑 숄더백','1382739','https://dabid-s3.s3.ap-northeast-2.amazonaws.com/20210815_151151.jpg',1500000,2,1,'P1629388892900');
/*!40000 ALTER TABLE `live` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20 10:26:16
